//
//  XFKFSUtilitiPopSelectItemsView.h
//  XF_XFT
//
//  Created by CWC on 17/8/29.
//  Copyright © 2017年 CWC. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CWCUtilitiPopSelectItemsViewSelectDelegate <NSObject>

@optional
/**
 选择item的回调

 @param index 标记位
 */
- (void)selectWithIndext:(NSInteger)index;

/**
 视图移除后的回调
 */
- (void)curentViewDidDismiss;
@end

typedef NS_ENUM(NSInteger, CWCPopType)
{
    CWCType_Left,
    CWCType_Right,

};

@interface CWCUtilitiPopSelectItemsView : NSObject

/**
 初始化

 @param selectArr 可选数组

 @return 实例
 */
- (instancetype)initWithSelectArr:(NSMutableArray *)selectArr;

/**
 显示视图

 @param selectView 目标视图
 */
- (void)presenFromeSelectView:(UIView *)selectView;

/**
 移除视图
 */
- (void)dismissAction;

/**
 *  代理
 */
@property (nonatomic, weak) id <CWCUtilitiPopSelectItemsViewSelectDelegate> delegate;
/**
 *  视图底图
 */
@property (nonatomic, strong) UIView *managerView;
/**
 *  弹出原始位置
 */
@property (nonatomic, assign) CWCPopType popType;
@end
