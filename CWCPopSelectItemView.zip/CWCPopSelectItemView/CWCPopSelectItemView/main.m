//
//  main.m
//  CWCPopSelectItemView
//
//  Created by CWC on 17/8/29.
//  Copyright © 2017年 CWC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
