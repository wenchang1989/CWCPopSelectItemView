//
//  ViewController.m
//  CWCPopSelectItemView
//
//  Created by CWC on 17/8/29.
//  Copyright © 2017年 CWC. All rights reserved.
//

#import "ViewController.h"
#import "CWCUtilitiPopSelectItemsView.h"

@interface ViewController ()<CWCUtilitiPopSelectItemsViewSelectDelegate>
/**
 *  pop视图
 */
@property (nonatomic, strong) CWCUtilitiPopSelectItemsView *managerObject;

/**
 *  显示标签
 */
@property (nonatomic, strong) UILabel *myLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.view.backgroundColor = [UIColor cyanColor];
    
    UIButton *button1 = [[UIButton alloc] initWithFrame:CGRectMake(0, 40, 40, 30)];
    button1.backgroundColor = [UIColor redColor];
    [button1 addTarget:self action:@selector(button1Select:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:button1];
    
    
    UIButton *button2 = [[UIButton alloc] initWithFrame:CGRectMake(self.view.frame.size.width-60, 200, 40, 30)];
    button2.backgroundColor = [UIColor blueColor];
    [button2 addTarget:self action:@selector(button2Select:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:button2];
    
    self.myLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 40)];
    self.myLabel.backgroundColor = [UIColor clearColor];
    self.myLabel.textColor = [UIColor grayColor];
    self.myLabel.text = @"请选择";
    self.myLabel.textAlignment = NSTextAlignmentCenter;
    self.myLabel.center = self.view.center;
    
    [self.view addSubview:self.myLabel];
    
}

- (void)button1Select:(UIButton *)sender{

    [self showpopView:sender popType:CWCType_Left];
    
}

- (void)button2Select:(UIButton *)sender{

    [self showpopView:sender popType:CWCType_Right];
    
}

- (void)showpopView:(UIView *)curentView popType:(CWCPopType)type{

    self.managerObject = [[CWCUtilitiPopSelectItemsView alloc] initWithSelectArr:[@[@"第一个",@"第二个",@"第三个"] mutableCopy]];
    
    self.managerObject.delegate = self;
    self.managerObject.popType = type;
    [self.managerObject presenFromeSelectView:curentView];
}

- (void)selectWithIndext:(NSInteger)index{

    NSArray *arr = @[@"第一个",@"第二个",@"第三个"];
    
    self.myLabel.text = arr[index];
    
}

- (void)curentViewDidDismiss{

    NSLog(@"就这么消失了===");
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
