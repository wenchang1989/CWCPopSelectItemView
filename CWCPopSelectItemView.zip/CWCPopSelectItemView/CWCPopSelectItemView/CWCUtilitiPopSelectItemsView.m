//
//  XFKFSUtilitiPopSelectItemsView.m
//  XF_XFT
//
//  Created by CWC on 17/8/29.
//  Copyright © 2017年 fang.com. All rights reserved.
//

#import "CWCUtilitiPopSelectItemsView.h"

#define SCREENWIDTH [UIScreen mainScreen].bounds.size.width
#define SCREENHIGHT [UIScreen mainScreen].bounds.size.height
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]

@interface CWCUtilitiPopSelectItemsView ()<UITableViewDelegate, UITableViewDataSource>

/**
 *  可选数组
 */
@property (nonatomic, strong) NSMutableArray *selectArr;
/**
 *  视图
 */
@property (nonatomic, strong) UITableView *myTableView;
/**
 *  底图
 */
@property (nonatomic, strong) UIView *backGroundView;

/**
 *  原始frame
 */
@property (nonatomic, assign) CGRect originFrame;
/**
 *  目标frame
 */
@property (nonatomic, assign) CGRect signFrame;

@end

@implementation CWCUtilitiPopSelectItemsView

- (instancetype)init{

    self = [super init];
    if (self) {
        
    }
    return self;
}

- (instancetype)initWithSelectArr:(NSMutableArray *)selectArr{

    self = [super init];
    if (self) {
        
        _selectArr = selectArr;
        
    }
    return self;
    
}

- (void)presenFromeSelectView:(UIView *)selectView{

    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    
    CGRect frame = [selectView convertRect:selectView.bounds toView:keyWindow];
    if (self.popType == CWCType_Right) {
        CGFloat curentY = CGRectGetMaxY(frame);
        CGFloat curentX = CGRectGetMaxX(frame);

        CGFloat originX = curentX-7;
        CGFloat originY = curentY+15;

        [keyWindow addSubview:self.backGroundView];

        [self.managerView addSubview:self.myTableView];

        self.managerView.frame = CGRectMake(originX-1, originY, 1, 1);
        self.originFrame = self.managerView.frame;
        [keyWindow addSubview:self.managerView];

        [UIView animateWithDuration:0.5f animations:^{
            self.managerView.frame = CGRectMake(originX-110, originY, 110, _selectArr.count*44);
            self.signFrame = self.managerView.frame;
        } completion:^(BOOL finished) {
            
        }];

    }else if (self.popType == CWCType_Left){
    
        CGFloat curentY = CGRectGetMaxY(frame);
        CGFloat curentX = CGRectGetMinX(frame);
        
        CGFloat originX = curentX+7;
        CGFloat originY = curentY+15;
        
        [keyWindow addSubview:self.backGroundView];
        
        [self.managerView addSubview:self.myTableView];
        
        self.managerView.frame = CGRectMake(originX, originY, 1, 1);
        self.originFrame = self.managerView.frame;
        [keyWindow addSubview:self.managerView];
        
        [UIView animateWithDuration:0.5f animations:^{
            self.managerView.frame = CGRectMake(originX, originY, 110, _selectArr.count*44);
            self.signFrame = self.managerView.frame;
        } completion:^(BOOL finished) {
            
        }];
        
    }
        
}

- (void)dismissAction{

    CGFloat X = CGRectGetMaxX(self.managerView.frame);
    CGFloat Y = CGRectGetMinY(self.managerView.frame);
    
    [UIView animateWithDuration:0.5f animations:^{
        self.managerView.frame = self.originFrame;
    } completion:^(BOOL finished) {
        
        [self.backGroundView removeFromSuperview];
        [self.managerView removeFromSuperview];
        
        self.managerView = nil;
        self.myTableView = nil;
        
        
        
    }];
    
}

#pragma mark=视图布局
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{

    return 1;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return _selectArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    return 44;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell *cell = [self.myTableView dequeueReusableCellWithIdentifier:@"selectCell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"selectCell"];
    }
    cell.backgroundColor = [UIColor clearColor];
    cell.contentView.backgroundColor = [UIColor clearColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryType = UITableViewCellAccessoryNone;
    
    if ([cell.contentView viewWithTag:829]) {
        UILabel *label = (UILabel *)[cell.contentView viewWithTag:829];
        label.text = _selectArr[indexPath.row];
    }else{
    
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 12, 90, 20)];
        label.backgroundColor = [UIColor clearColor];
        label.textColor = [UIColor whiteColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont systemFontOfSize:14.0f];
        label.tag = 829;
        label.text = _selectArr[indexPath.row];
        [cell.contentView addSubview:label];
    }
    
    UILabel *lineLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 43.5, 90, 0.5)];
    lineLabel.backgroundColor = [self colorWithHexString:@"#999999"];
    if (indexPath.row != self.selectArr.count-1) {
        [cell.contentView addSubview:lineLabel];
    }
    
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    if ([self.delegate respondsToSelector:@selector(selectWithIndext:)]) {
        [self.delegate selectWithIndext:indexPath.row];
    }
    
    [self dismissAction];
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (UITableView *)myTableView{

    if (!_myTableView) {
        _myTableView = [[UITableView alloc] initWithFrame:CGRectMake(10, 0, 90, _selectArr.count*44) style:UITableViewStylePlain];
        _myTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _myTableView.backgroundColor = [UIColor clearColor];
        _myTableView.delegate = self;
        _myTableView.dataSource = self;
        _myTableView.bounces = NO;
    }
    
    return _myTableView;
}

- (NSMutableArray *)selectArr{

    if (!_selectArr) {
        _selectArr = [NSMutableArray array];
    }
    return _selectArr;
}

- (UIView *)managerView{

    if (!_managerView) {
        _managerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 1, 1)];
        _managerView.backgroundColor = RGBACOLOR(13, 28, 59, 0.9);
//        [UtilityHelper colorWithHexString:@"#0d1c3b"];
        _managerView.clipsToBounds = YES;
        _managerView.layer.masksToBounds = YES;
        _managerView.layer.cornerRadius = 1.5f;
    }
    return _managerView;
}

- (UIView *)backGroundView{

    if (!_backGroundView) {
        _backGroundView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREENWIDTH, SCREENHIGHT)];
        _backGroundView.backgroundColor = [UIColor blackColor];
        _backGroundView.alpha = 0.1f;
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissAction)];
        [_backGroundView addGestureRecognizer:tap];
    }
    return _backGroundView;
}

- (UIColor *) colorWithHexString: (NSString *) stringToConvert
{
    NSString *cString = [[stringToConvert stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    //if ([cString length] < 6) return DEFAULT_VOID_COLOR;
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    if ([cString hasPrefix:@"#"]) cString = [cString substringFromIndex:1];
    //if ([cString length] != 6) return DEFAULT_VOID_COLOR;
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    //SL_Log(@"%f:::%f:::%f",((float) r / 255.0f),((float) g / 255.0f),((float) b / 255.0f));
    
    return RGBACOLOR(r / 255.0f,g / 255.0f,b / 255.0f, 1);
}

@end
